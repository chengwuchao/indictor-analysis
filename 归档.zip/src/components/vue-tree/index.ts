import VueTree from './VueTree.vue';

export default VueTree;
